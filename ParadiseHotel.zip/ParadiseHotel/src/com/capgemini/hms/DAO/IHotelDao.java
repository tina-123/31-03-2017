package com.capgemini.hms.DAO;

import java.util.List;

import com.capgemini.hms.Exception.HotelException;
import com.capgemini.hms.dto.BookingDetails;
import com.capgemini.hms.dto.Hotel;
import com.capgemini.hms.dto.RoomDetails;
import com.capgemini.hms.dto.Users;

public interface IHotelDao 
{
 /* public boolean isUserExist(String userId) throws HotelException;
  public Hotel addHotel(Hotel hotel) throws HotelException;
  public Hotel removeHotel(String hotelId) throws HotelException;
  public void  updateHotel(Hotel hotel) throws HotelException;
  public List<RoomDetails> ShowRoomDetails() throws HotelException;
  public  RoomDetails getRoomDetails(String roomId) throws HotelException;
  public void  updateRoomDetails(RoomDetails room) throws HotelException;*/
	
	
	
	public int addHotel(Hotel hotel) throws HotelException;
	List<Hotel> showAllHotels() throws HotelException;
	public void updateHotels(Hotel hotel) throws HotelException;
	List<Hotel> searchHotels(String city) throws HotelException;
   public void removeHotel(String hotelId) throws HotelException;


	
	List<RoomDetails> showAllRooms() throws HotelException;
	public int addRoomDetails(RoomDetails room) throws HotelException;
	 public void  updateRoomDetails(RoomDetails room) throws HotelException;
	public RoomDetails getRoomDetails(String roomId) throws HotelException;

	 
		List<BookingDetails> showAllBookings() throws HotelException;
		public int addBookingDetails(BookingDetails book) throws HotelException;
		
		
		  public boolean isUserExist(String userId) throws HotelException;
		  public int addUSer(Users user) throws HotelException;
		  List<Users> showAll() throws HotelException;


}
