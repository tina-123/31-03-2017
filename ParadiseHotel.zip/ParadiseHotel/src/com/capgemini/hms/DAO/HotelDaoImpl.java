package com.capgemini.hms.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;








import com.capgemini.hms.Exception.HotelException;
import com.capgemini.hms.dto.BookingDetails;
import com.capgemini.hms.dto.Hotel;
import com.capgemini.hms.dto.RoomDetails;
import com.capgemini.hms.dto.Users;
import com.capgemini.hms.util.DBUtil;



public class HotelDaoImpl implements IHotelDao {

	
	Connection con;
	Statement st;
	PreparedStatement pst;
	ResultSet rs;
	@Override
	public boolean isUserExist(String userId) throws HotelException
	{
		
		return false;
	}

	@Override
	public int addHotel(Hotel hotel) throws HotelException 
	{			int uId  = 0;

		try
		{
			
			con=DBUtil.getConnection();
			st=con.createStatement();
			
			System.out.println(con);
			
			ResultSet rs=st.executeQuery("select seqhotel.nextVal from dual");
			if(rs.next()==false)
			System.out.println("Something went wrong");
			
			uId = rs.getInt(1);
			String id=rs.getString(1);
			
			System.out.println("Hotel id"+ id);
			hotel.setHotelId(id);
			String insertQuery="INSERT INTO Hotel VALUES(?,?,?,?,?,?,?,?,?,?,?)";
			pst=con.prepareStatement(insertQuery);
			pst.setString(1,id);
			pst.setString(2,hotel.getCity());
			pst.setString(3,hotel.getHotelName());
			pst.setString(4,hotel.getAddress());
			pst.setString(5,hotel.getDescription());
			pst.setFloat(6,hotel.getAvgRatePerNight());
			pst.setString(7,hotel.getPhoneNo1());
			pst.setString(8,hotel.getPhoneNo2());
			pst.setString(9,hotel.getRating());
			pst.setString(10,hotel.getEmail());
			pst.setString(11,hotel.getFax());
			pst.execute();
			
		}
		catch (SQLException e) 
		{
			e.printStackTrace();	
			//throw new HotelException(e.getMessage());
		}
		catch(Exception e)
		{
			e.printStackTrace();
			//throw new HotelException(e.getMessage());

		}
		finally
		{
			try 
			{

				pst.close();
				st.close();
				con.close();
			} 
			catch (SQLException e) 
			{
			//e.printStackTrace();
				
			}
		}
		
		return  uId;
	
	}

	@Override
	public List<Hotel> showAllHotels() throws HotelException 
	{
		List<Hotel> mylist = new ArrayList();
		try 
		{
			con = DBUtil.getConnection();
			pst = con.prepareStatement("SELECT * FROM Hotel");
			ResultSet result = pst.executeQuery();

			while(result.next())
			{
				Hotel hotel = new Hotel();

				hotel.setHotelId(result.getString(1));
				hotel.setCity(result.getString(2));
				hotel.setHotelName(result.getString(3));
				hotel.setAddress(result.getString(4));
				hotel.setDescription(result.getString(5));
				hotel.setAvgRatePerNight(result.getFloat(6));
				hotel.setPhoneNo1(result.getString(7));
				hotel.setPhoneNo2(result.getString(8));
				hotel.setRating(result.getString(9));
				hotel.setEmail(result.getString(10));
				hotel.setFax(result.getString(11));
				
				mylist.add(hotel);
			}
		} 

		catch (SQLException e) {
			throw new HotelException(e.getMessage());
		}
		finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return mylist;

		

		
	}

	@Override
	public void updateHotels(Hotel hotel) throws HotelException
	
	{
		try 
		{
			con=DBUtil.getConnection();
			String id= hotel.getHotelId();
			String city =hotel.getCity();
			String hotel_name =hotel.getHotelName();
			String address = hotel.getAddress();
			String description = hotel.getDescription();
			float avg_rate_per_night = hotel.getAvgRatePerNight();
			String phone_no1 =hotel.getPhoneNo1();
			String phone_no2 =hotel.getPhoneNo2();
			String rating =hotel.getRating();
			String email = hotel.getEmail();
			
			
			pst=con.prepareStatement("UPDATE hotel set city=? hotel_name=? address=? description=? avg_rate_per_night=? phone_no1=? phone_no2=? rating=?  email=? where hotel_id=?");
			
			pst.setString(1,city );
			pst.setString(2, hotel_name);
			pst.setString(3, address);
			pst.setString(4, description);
			pst.setFloat(5, avg_rate_per_night);
			pst.setString(6, phone_no1);
			pst.setString(7, phone_no2);
			pst.setString(8, rating);
			pst.setString(9, email);
			
			pst.execute();

			
		} 
		catch (SQLException e) 
		{
			
			//e.printStackTrace();
			throw new HotelException(e.getMessage());
		}
		catch(Exception e)
		{
			//e.printStackTrace();
			throw new HotelException(e.getMessage());

		}
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
			//e.printStackTrace();
				
			}
		}
	}
		
	

	@Override
	public List<Hotel> searchHotels(String city) throws HotelException 
	{
		List<Hotel> mylist = new ArrayList<Hotel>();
		try 
		{
	
			
			con = DBUtil.getConnection();
			String querySh = "SELECT * FROM HOTEL WHERE CITY=?";
			pst = con.prepareStatement(querySh);
			pst.setString(1, city);
			ResultSet result = pst.executeQuery();

		
			while(result.next())
			{
				Hotel hotel = new Hotel();
			
				hotel.setHotelId(result.getString(1));
				hotel.setCity(result.getString(2));
				hotel.setHotelName(result.getString(3));
				hotel.setAddress(result.getString(4));
				hotel.setDescription(result.getString(5));
				hotel.setAvgRatePerNight(result.getFloat(6));
				hotel.setPhoneNo1(result.getString(7));
				hotel.setPhoneNo2(result.getString(8));
				hotel.setRating(result.getString(9));
				hotel.setEmail(result.getString(10));
				hotel.setFax(result.getString(11));
				
				mylist.add(hotel);
	
			}
		} 

		catch ( SQLException e) {
			e.printStackTrace();
			//throw new HotelException(e.getMessage());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return mylist;
	}

	@Override
	public List<RoomDetails> showAllRooms() throws HotelException 
	
	{
		List<RoomDetails> rdetails = new ArrayList<RoomDetails>();
		try(Connection con = DBUtil.getConnection())
		{
			Statement stm = con.createStatement();
			ResultSet res = stm.executeQuery("select * from RoomDetails");
			
			while (res.next())
			{
				RoomDetails rdetail = new RoomDetails();
				
				rdetail.setHotelId(res.getString("hotel_id"));
				rdetail.setRoomId(res.getString("room_id"));
				rdetail.setRoomNo(res.getString("room_no"));
				rdetail.setRoomType(res.getString("room_type"));
				rdetail.setPerNightRate(res.getFloat("per_night_rate"));
				rdetail.setAvailability(res.getString("availability"));
				rdetail.setPhoto(res.getString("photo"));
				
				rdetails.add(rdetail);
			}
		} 
		catch (SQLException e) 
		{
			//e.printStackTrace();	
			throw new HotelException(e.getMessage());
		}
		
		catch(Exception e)
		{
			//e.printStackTrace();
			throw new HotelException(e.getMessage());

		}
		
		return rdetails;
	
	}

	@Override
	public int addRoomDetails(RoomDetails room) throws HotelException {
		int rId = 0;
		
		try 
		{
			System.out.println(room);
			con=DBUtil.getConnection();
			st=con.createStatement();
			
			System.out.println(con);
			
			ResultSet rs=st.executeQuery("select ROOM_HBMS_SEQ.NEXTVAL from dual");
			if(rs.next()==false)
				System.out.println("Something went wrong");	
			
			rId = rs.getInt(1);
			String id=rs.getString(1);
			System.out.println(id);
			
			String query = "INSERT INTO RoomDetails Values(?,?,?,?,?,?,?)";
			pst = con.prepareStatement(query);
			
			pst.setString(1, room.getHotelId());
			pst.setString(2, id);
			pst.setString(3, room.getRoomNo());
			pst.setString(4, room.getRoomType());
			pst.setFloat(5, room.getPerNightRate());
			pst.setString(6, room.getAvailability());
			pst.setString(7, room.getPhoto());
			pst.execute();	
			
		} 	
		catch ( SQLException e) 
		{
			e.printStackTrace();
			//throw new HotelException("Error Occured while adding hotel's data");
		}
		catch(Exception e)
		{
			e.printStackTrace();	
		}
		
		finally
		{
			try 
			{
				pst.close();
				st.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
		System.out.println("String id"+rId);
		
		return rId;
	}

	@Override
	public List<BookingDetails> showAllBookings() throws HotelException 
	{
		System.out.println("In dao");
		
		List<BookingDetails> mylist = new ArrayList();
		try {
			con = DBUtil.getConnection();
			pst = con.prepareStatement("SELECT * FROM BOOKINGDetails");

			ResultSet result = pst.executeQuery();

			while(result.next())
			{
				BookingDetails book = new BookingDetails();

				book.setBookId(result.getString(1));
				book.setRoomId(result.getString(2));
				book.setUserId(result.getString(3));
				book.setBookedFrom(result.getDate(4));
				book.setBookedTo(result.getDate(5));
				book.setNoOfAdults(result.getInt(6));
				book.setNoOfChildren(result.getInt(7));
				book.setAmount(result.getInt(8));
				
				mylist.add(book);
			}
		} 

		catch ( SQLException e) {
			throw new HotelException(e.getMessage());
		}
		finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return mylist;
	}

	@Override
	public int addBookingDetails(BookingDetails book) throws HotelException {
		int bId = 0;
		
		try 
		{
			con = DBUtil.getConnection();
			String query = "INSERT INTO BOOKINGDetails Values(BOOKING_HBMS_SEQ.NEXTVAL,?,?,?,?,?,?,?)";
			pst = con.prepareStatement(query);
			
			pst.setString(1, book.getRoomId());
			pst.setString(2, book.getUserId());
			pst.setDate(3, book.getBookedFrom());
			pst.setDate(4, book.getBookedTo());
			pst.setInt(5, book.getNoOfAdults());
			pst.setInt(6, book.getNoOfChildren());
			pst.setFloat(7, book.getAmount());
			
			pst.executeUpdate();	
			
			PreparedStatement pstm1 = con.prepareStatement("SELECT BOOKING_HBMS_SEQ.CURRVAL FROM DUAL");
			ResultSet rs = pstm1.executeQuery();

			while(rs.next())
			{
				bId = rs.getInt(1);
			}

		} 	
		catch ( SQLException e) 
		{
			//e.printStackTrace();
			throw new HotelException("Error Occured while adding booking info");
		}
		
		
		finally
		{
			try 
			{
				con.close();
				pst.close();
			} 
			catch (SQLException e) 
			{
				//e.printStackTrace();
			}
		}
		return bId;
	}

	@Override
	public int addUSer(Users user) throws HotelException {
		int uId  = 0;
		
		try 
		{
			con = DBUtil.getConnection();
			String query = "INSERT INTO USERS Values(USER_HBMS_SEQ.NEXTVAL,?,?,?,?,?,?,?)";
			pst = con.prepareStatement(query);
			
			pst.setString(1, user.getPassword());
			pst.setString(2, user.getRole());
			pst.setString(3, user.getUsername());
			pst.setString(4, user.getMobileNo());
			pst.setString(5, user.getPhoneNo());
			pst.setString(6, user.getAddress());
			pst.setString(7, user.getEmail());
			
			
			
			pst.executeUpdate();	
			
			PreparedStatement pstm1 = con.prepareStatement("SELECT USER_HBMS_SEQ.CURRVAL FROM DUAL");
			ResultSet rs = pstm1.executeQuery();

			while(rs.next())
			{
				uId = rs.getInt(1);
			}

		} 	
		catch (SQLException e) 
		{
			//e.printStackTrace();
			throw new HotelException("Error Occured while adding user's data");
		}
		
		
		finally
		{
			try 
			{
				con.close();
				pst.close();
			} 
			catch (SQLException e) 
			{
				//e.printStackTrace();
			}
		}
		return uId;
	}

	@Override
	public List<Users> showAll() throws HotelException 
	{
		System.out.println("in dao");
		List<Users> mylist = new ArrayList();
		try {
			con = DBUtil.getConnection();
			pst = con.prepareStatement("SELECT * FROM USERS");

			ResultSet result = pst.executeQuery();

			while(result.next())
			{
				Users user = new Users();

				user.setUserId(result.getString(1));
				user.setPassword(result.getString(2));
				user.setRole(result.getString(3));
				user.setUsername(result.getString(4));
				user.setMobileNo(result.getString(5));
				user.setPhoneNo(result.getString(6));
				user.setAddress(result.getString(7));
				user.setEmail(result.getString(8));
				
				mylist.add(user);
			}
		} 

		catch ( SQLException e) {
			throw new HotelException(e.getMessage());
		}
		finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return mylist;

	}

	
	@Override
	public void removeHotel(String hotelId) throws HotelException 
	{

		try 
		{
			con = DBUtil.getConnection();
			
			String query = "DELETE from Hotel where hotel_id = ?";
					
			pst = con.prepareStatement(query);
			
			pst.setString(1, hotelId);
	
			pst.execute();	

		} 	
		catch ( SQLException e) 
		{
			e.printStackTrace();
			//throw new HotelException("Error Occured while removing info");
		}
		
		
		finally
		{
			try 
			{
				con.close();
				pst.close();
			} 
			catch (SQLException e) 
			{
				//e.printStackTrace();
			}
		}
	
	}



	@Override
	public void updateRoomDetails(RoomDetails room) throws HotelException 
	{
		try 
		{
			con=DBUtil.getConnection();
			String hotel_id = room.getHotelId();
			String room_id = room.getRoomId();
			String room_no = room.getRoomNo();
			String room_type = room.getRoomType();
			float per_night_rate = room.getPerNightRate();
			String availability = room.getAvailability();
			String photo = room.getPhoto();
			
			pst=con.prepareStatement
					("UPDATE RoomDetails set hotel_id=? room_no=? room_type=? per_night_rate=? availability=? photo=?  where room_id=?");
			
			pst.setString(1, hotel_id);
			pst.setString(2, room_id);
			pst.setString(3, room_no);
			pst.setString(4, room_type);
			pst.setFloat(5, per_night_rate);
			pst.setString(6, availability);
			pst.setString(7, photo);

			pst.execute();

			
			
		}
		catch (SQLException e) 
		{
			
			//e.printStackTrace();
			throw new HotelException(e.getMessage());
		}
		catch(Exception e)
		{
			//e.printStackTrace();
			throw new HotelException(e.getMessage());

		}
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
			//e.printStackTrace();
				
			}
		}		
	}



	@Override
	public RoomDetails getRoomDetails(String roomId) throws HotelException
	{
		RoomDetails room=null;	
		try 
		{
			System.out.println(roomId);
			con=DBUtil.getConnection();		
			//System.out.println("getUserDetails*****con is**** "+con);
			String selQry="Select * from roomDetails where room_Id=?";
			pst=con.prepareStatement(selQry);
			pst.setString(1,roomId);
			rs=pst.executeQuery();
			rs.next();
			room=new RoomDetails();
			room.setHotelId(rs.getString("hotel_id"));
			room.setRoomId(rs.getString("room_id"));
			room.setRoomNo(rs.getString("room_no"));
			room.setRoomType(rs.getString("room_type"));
			room.setPerNightRate(rs.getFloat("per_night_rate"));
			room.setAvailability(rs.getString("availability"));
			room.setPhoto(rs.getString("photo"));
			System.out.println(room);
		} 
		catch (SQLException e) 
		{

			e.printStackTrace();
		} 
		

		return room;
	}

	}


