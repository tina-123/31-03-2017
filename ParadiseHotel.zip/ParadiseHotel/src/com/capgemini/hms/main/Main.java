package com.capgemini.hms.main;



import java.sql.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.hms.Exception.HotelException;
import com.capgemini.hms.dto.BookingDetails;
import com.capgemini.hms.dto.Hotel;
import com.capgemini.hms.dto.RoomDetails;
import com.capgemini.hms.dto.Users;
import com.capgemini.hms.service.HotelServiceImpl;
import com.capgemini.hms.service.IHotelService;

public class Main 
{
	private IHotelService hotelService=new HotelServiceImpl();

	public static void main(String[] args) 
	{
		Main hsUI = new Main();
		
		while(true)
		{
		hsUI.showMenu();
		}
		
	}
	public void showMenu()
	{
		Scanner scanner = new Scanner(System.in);
		System.out.println("1) Add Hotel");
		System.out.println("2) Update Hotel");
		System.out.println("3) View RoomDetails");
		System.out.println("4) View Hotel Details");
		System.out.println("5)View Booking");
		System.out.println("6) Show All USers");
		System.out.println("7) Search Hotel By City");
		System.out.println("8) Remove Hotel By Id");
		System.out.println("9) Add Room Details");
		
		int choice = scanner.nextInt();
		switch (choice)
		{
		case 1: addHotel(); 
		break;
		/*case 2: updateHotel();
		break;*/
		case 3: ShowRoomDetails(); 
		break;
		case 4: ShowHotelDetails();
		break;
		case 5: showAllBookings();
		break;
		case 6: showAll();
		break;
		case 7: searchHotels();
		break;
		case 8: removeHotel();
		break;
		case 9: addRoomDetails();
		break;
	}

}
	
	
	
	
	
	private void addHotel() 
	{
		Scanner scanner= new Scanner(System.in);
		System.out.println("Provide Hotel Details");
		
		System.out.println("City");
		String city = scanner.next();
		
		System.out.println("HotelName");
		String hotelName = scanner.next();
		
		System.out.println("Address");
		String address = scanner.next();
		
		System.out.println("Description");
		String description = scanner.next();
		
		System.out.println("AvgRatePerNight");
		Float avgRatePerNight = scanner.nextFloat();
		
		System.out.println("PhoneNo1");
		String phoneNo1 = scanner.next();
		
		System.out.println("PhoneNo2");
		String phoneNo2 = scanner.next();
		
		System.out.println("Rating");
		String rating = scanner.next();
		
		System.out.println("Email");
		String email = scanner.next();
		
		System.out.println("Fax");
		String fax = scanner.next();
		
		Hotel hotel = new Hotel();
		
		
		hotel.setCity(city);
		hotel.setHotelName(hotelName);
		hotel.setAddress(address);
		hotel.setDescription(description);
		hotel.setAvgRatePerNight(avgRatePerNight);
		hotel.setPhoneNo1(phoneNo1);
		hotel.setPhoneNo2(phoneNo2);
		hotel.setRating(rating);
		hotel.setEmail(email);
		hotel.setFax(fax);
		
		try 
		{
		int hotel1 = hotelService.addHotel(hotel);
			System.out.println("Hotal Details added succesufully with id" + hotel1);
		}
		catch(HotelException e)
		{
			e.printStackTrace();
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
	}
	/*
	private void updateHotel()
	{
		
		Scanner scanner =new Scanner(System.in);
		System.out.println("updating HotelDetails Information");
		
		System.out.println("\n Hotel ID:");
		int id = scanner.nextInt();
		
		try
		{
			// attempt to get employee assuming id passed is valid
			Hotel employee = hotelService.get
			
			//since emp object is retrieved updated it and send to update 
			
			System.out.println("Name: " + employee.getId());
			
			System.out.println("Do you want to update Name (y/n)? ");
			
			char reply= scanner.next().toLowerCase().charAt(0);
			
	}*/
	
	private void ShowRoomDetails() 
	{
		try
		{
			List<RoomDetails> rooms = hotelService.showAllRooms();
			
			Iterator<RoomDetails> it= rooms.iterator();
			
			System.out.println("Hotel_ID \troom_id \troom_no \troom_type \tper_night_rate \tavailability \tphoto");
			
			while(it.hasNext())
			{
				RoomDetails room = it.next();
				
				System.out.println(room.getHotelId() + "\t" + room.getRoomId()+"\t" +room.getRoomNo()+ "\t" + room.getRoomType() + "\t" + room.getPerNightRate()+ "\t" + room.getAvailability() + "\t" + room.getPhoto());
				
			}
			
			
		}
		catch(HotelException e)
		{
			e.printStackTrace();
		}
		
	}
	
	private void ShowHotelDetails() 
	{
		try
		{
			List<Hotel> hotels = hotelService.showAllHotels();
			
			Iterator<Hotel> it= hotels.iterator();
			
			System.out.println("Hotel_ID \tCity \tHotel Name \tAddress \tDescription \tRate \tPhone No1\tPhone No2\tRating\tEmail\tFax");
			
			while(it.hasNext())
			{
				Hotel hotel = it.next();
				
				System.out.println(hotel.getHotelId() + "\t" + hotel.getCity()+"\t" +hotel.getHotelName()+ "\t" + hotel.getAddress() + "\t" + hotel.getDescription()+ "\t" + hotel.getAvgRatePerNight() + "\t" + hotel.getPhoneNo1()+ "\t" + hotel.getPhoneNo2()+ "\t" + hotel.getRating()+ "\t" + hotel.getEmail()+ "\t" + hotel.getFax());
				
			}
			
			
		}
		catch(HotelException e)
		{
			e.printStackTrace();
		}
		
	}
	
	private void showAllBookings() 
	{
		try
		{
			List<BookingDetails> bookings = hotelService.showAllBookings();
			
			Iterator<BookingDetails> it= bookings.iterator();
			
			System.out.println("Book_ID \tRoomId \tUserId \tBooked From \tbooked To \tAdults \tChildren\tAmount");
			
			while(it.hasNext())
			{
				BookingDetails booking = it.next();
				
				System.out.println(booking.getBookId() + "\t" + booking.getRoomId()+"\t" +booking.getUserId()+ "\t" + booking.getBookedFrom() + "\t" + booking.getBookedTo()+ "\t" + booking.getNoOfAdults() + "\t" + booking.getNoOfChildren()+ "\t" +booking.getAmount());
				
			
			
			}
			
			
		}
		catch(HotelException e)
		{
			e.printStackTrace();
		}
		
	}



private void showAll() 
{
	try
	{
		List<Users> users=hotelService.showAll();
		
		Iterator<Users> it= users.iterator();
		
		System.out.println("Book_ID \tRoomId \tUserId \tBooked From \tbooked To \tAdults \tChildren\tAmount");
		
		while(it.hasNext())
		{
			Users user = it.next();
			
			System.out.println(user.getUserId() + "\t" + user.getPassword()+"\t" +user.getRole()+ "\t" + user.getUsername() + "\t" + user.getMobileNo()+ "\t" + user.getPhoneNo() + "\t" + user.getAddress()+ "\t" +user.getEmail());
		
		}
		
		
	}
	catch(HotelException e)
	{
		e.printStackTrace();
	}
}

private void searchHotels() 
{
	Scanner scanner= new Scanner(System.in);
	System.out.println("Provide Hotel City");
	
	System.out.println("City");
	String city = scanner.next();
	
	List<Hotel> hotel = hotelService.searchHotels(city);
	System.out.println(hotel);	
	
	Iterator<Hotel> it= hotel.iterator();
	
	while(it.hasNext())
	{
		Hotel h = it.next();
		
		System.out.println(h);
	}
}

private void removeHotel() 
{
	Scanner scanner= new Scanner(System.in);
	System.out.println("Provide Hotel ID");
	
	System.out.println("ID");
	String id = scanner.next();
	
	hotelService.removeHotel(id);
	
}

private void addRoomDetails() 
{
	
	Scanner scanner= new Scanner(System.in);
	System.out.println("Provide Room Details");
	
	System.out.println("hotelId");
	String hotelId = scanner.next();
	/*
	System.out.println("Room Id");
	String roomId = scanner.next();*/
	
	System.out.println("Room No");
	String roomNo = scanner.next();
	
	System.out.println("Room Type");
	String roomType = scanner.next();
	
	System.out.println("Rate");
	Float rate = scanner.nextFloat();
	
	System.out.println("ava");
	String ava = scanner.next();
	
	System.out.println("Photo");
	String photo = scanner.next();
	
	
	RoomDetails room = new RoomDetails();
	
	
	room.setHotelId(hotelId);
	/*room.setRoomId(roomId);*/
	room.setRoomNo(roomNo);
	room.setRoomType(roomType);
	room.setPerNightRate(rate);
	room.setAvailability(ava);
	room.setPhoto(photo);
	
	try 
	{
	int room1 = hotelService.addRoomDetails(room);
		System.out.println("Room Details added succesufully with id" + room1);
	}
	catch(HotelException e)
	{
		e.printStackTrace();
	}
	catch (Exception e) 
	{
		e.printStackTrace();
	}
}

}


