package com.cg.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.bean.User;
import com.cg.util.DBUtil;

public class UserDaoImpl implements IUserDao {

	Connection con;
	Statement st;
	PreparedStatement pst;
	ResultSet rs;
	@Override
	public boolean isUserExist(String unm) throws SQLException 
	{
		boolean flag=false;
		con = DBUtil.getConnection();
		System.out.println("In user dao con is"+con);
		String selectQry="Select count(*) from cg_users where user_name=?";
		try {
			pst=con.prepareStatement(selectQry);
			pst.setString(1, unm);
			rs=pst.executeQuery();
			rs.next();
			int count=rs.getInt(1);
			if(count==1)
			{
				flag=true;
			}
			else
			{
				System.out.println("******"+rs);
				flag=false;
			}
			
		} 
		catch (SQLException e) 
		{
			
			e.printStackTrace();
		}
		finally
		{
			try {
				rs.close();
				pst.close();
				con.close();
			} 
			catch (SQLException e)
			{
				
				e.printStackTrace();
			}
		}
		return flag;
		
		
	}

	@Override
	public User getUserDetails(String un) throws SQLException
	{
		
		con=DBUtil.getConnection();
		System.out.println("getUserDetails   ********con is******"+con);
		String selQry="Select * from cg_users where user_name=?";
		User usr=null;
		
		try {
			pst=con.prepareStatement(selQry);
			pst.setString(1, un);
			rs=pst.executeQuery();
			rs.next();
			 usr= new User();
			usr.setUsername(rs.getString("user_name"));
			usr.setPassword(rs.getString("password"));
		} 
		catch (SQLException e) 
		{
			
			e.printStackTrace();
		}
		finally
		{
			try
			{
				rs.close();
				pst.close();
				con.close();
				
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			
		}
		
	return usr;
	}

}
