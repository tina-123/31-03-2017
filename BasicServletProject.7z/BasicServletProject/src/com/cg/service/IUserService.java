package com.cg.service;

import java.sql.SQLException;

import com.cg.bean.User;

public interface IUserService {

	public boolean isUserExist(String unm)throws SQLException;
	public User getUserDetails(String un) throws SQLException;
}
