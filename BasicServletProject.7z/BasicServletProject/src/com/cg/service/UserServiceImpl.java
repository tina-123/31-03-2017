package com.cg.service;

import java.sql.SQLException;

import com.cg.bean.User;
import com.cg.dao.IUserDao;
import com.cg.dao.UserDaoImpl;

public class UserServiceImpl implements IUserService {
	
	IUserDao userDao;
	public UserServiceImpl()
	{
		userDao = new UserDaoImpl();
	}
	@Override
	public boolean isUserExist(String unm) throws SQLException {
		
		return userDao.isUserExist(unm);
	}
	@Override
	public User getUserDetails(String un) throws SQLException {
		
		return userDao.getUserDetails(un);
	}
	

}
