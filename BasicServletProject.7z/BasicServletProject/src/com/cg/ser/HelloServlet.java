package com.cg.ser;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name = "HelloServletName", 
urlPatterns = { "/HelloServletMap" },
initParams={
		@WebInitParam(name="compName",value="Capgemini"),
		@WebInitParam(name="compLoc",value="Pune")})

public class HelloServlet extends HttpServlet 
{	
	ServletConfig conf;
	private static final long serialVersionUID = 1L;
       
   
    public HelloServlet() {
        super();
        System.out.println("HelloServelt()Initialized");
        
    }


	public void init(ServletConfig config) throws ServletException 
	{	
		conf=config;
		System.out.println("Init function of Helloservlet called***");
	}

	
	public void destroy() {
		System.out.println("Destory function of"+"HelloServlet called***");
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println(""
				+"In Do GET********************");
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{	
		String cn=conf.getInitParameter("compName");
		String cl=conf.getInitParameter("compLoc");
		String name = request.getParameter("txtName");
		//String name = "Ananyaa";
		System.out.println(""                     +"In Do Post********");
		PrintWriter out = response.getWriter();
		out.println("<hr/>");
		out.println("Welcome to  :"+ cn+ name +" To "+cl);
		out.println("<hr color='green' size='5'/>");
		
	}

}
