package com.cg.ser;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name = "SuccessServletName", urlPatterns = { "/SuccessServletMap" })
public class SuccessServlet extends HttpServlet {
	ServletConfig conf;
	private static final long serialVersionUID = 1L;
       
    
    public SuccessServlet() {
        super();
       System.out.println("In Successservlet init***");
    }

	
	public void init(ServletConfig config) throws ServletException {
		
		conf=config;
		System.out.println(" In SuccessServlet Init*****");
	}

	
	public void destroy() {
		System.out.println("In SuccessServelt Init***");
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		System.out.println(" In do get of successServelt init***");
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		ServletContext ctx = conf.getServletContext();
		String cn=ctx.getInitParameter("CountryName");
		String sn=ctx.getInitParameter("compState");
		RequestDispatcher rdH= ctx.getRequestDispatcher
				("/header.html");
		RequestDispatcher rdF= ctx.getRequestDispatcher("/footer.html");
		
		
		PrintWriter pw=response.getWriter();
		String unm=request.getParameter("txtUnm");
		rdH.include(request, response);	
		pw.println("<font color='blue'>Welcome you are a valid user:" + "</font>"+unm);
		pw.println("<br/>Your state and country name is:"+sn   + "   "+cn);
		rdF.include(request, response);
	}

}
