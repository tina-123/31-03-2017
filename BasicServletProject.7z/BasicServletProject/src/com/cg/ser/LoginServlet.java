package com.cg.ser;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bean.User;
import com.cg.service.IUserService;
import com.cg.service.UserServiceImpl;

@WebServlet("/LoginServletMap")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
    IUserService userService;
    public LoginServlet() {
        super();
        System.out.println("In Loginservlet init***");
    }

	
	public void init(ServletConfig config) throws ServletException {
		System.out.println(" In LoginServlet Init*****");
	}

	
	public void destroy() {
		System.out.println("In LoginServelt Init***");
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		System.out.println(" In do get of loginServelt init***");
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		userService = new UserServiceImpl();
		System.out.println(" In doPost of Login servlet.....");
		String un=request.getParameter("txtUnm");
		String pw=request.getParameter("txtpwd");
		try {
			if(userService.isUserExist(un))
			{
				User user=userService.getUserDetails(un);
				if(un.equalsIgnoreCase(
						user.getUsername())&&
						pw.equalsIgnoreCase(user.getPassword()))
				{
					RequestDispatcher rdUserExist=request.getRequestDispatcher("/SuccessServletMap");
					rdUserExist.forward(request, response);
					
				}
				else
				{
					RequestDispatcher rdFailure=
							request.getRequestDispatcher("/failure.html");
					rdFailure.forward(request, response);
				}
				
				
			}
			else
			{
				RequestDispatcher rdUserNotExist = request.getRequestDispatcher("/register.html");
				rdUserNotExist.forward(request, response);
			}
		} 
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
