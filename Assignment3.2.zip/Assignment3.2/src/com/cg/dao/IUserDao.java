package com.cg.dao;

import java.util.ArrayList;

import com.cg.bean.User;

public interface IUserDao {
	public int insertUser(User user);
	public ArrayList<User> getAllUsers();

}
